#!/usr/bin/env python3
"""
finder.py
Scans for the 'CS60' Wi-Fi beacon and prints RSSI and vendor info strings.

Used ChatGPT for method formatting and control flow.
"""

import argparse
import subprocess
import time
import os
from datetime import datetime
from scapy.all import sniff, RadioTap, Dot11, Dot11Beacon, Dot11Elt

# ---------------------------
# Channel helpers
# ---------------------------
def set_channel_via_monitor_script(script_path, iface, channel):
    try:
        subprocess.check_call([script_path, iface, str(channel)],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(0.25)
        return True
    except Exception as e:
        print(f"[!] monitor-mode script failed: {e}")
        return False

def set_channel_iwconfig(iface, channel):
    try:
        subprocess.check_call(["iwconfig", iface, "channel", str(channel)],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(0.25)
        return True
    except Exception as e:
        print(f"[!] iwconfig failed to set channel {channel}: {e}")
        return False

def set_channel(iface, channel, monitor_script_path=None):
    if monitor_script_path:
        if set_channel_via_monitor_script(monitor_script_path, iface, channel):
            return True
        else:
            print("[*] Falling back to iwconfig...")
    return set_channel_iwconfig(iface, channel)

# ---------------------------
# RSSI and Vendor IE helpers
# ---------------------------
def rssi_from_pkt(pkt):
    if hasattr(pkt, "dBm_AntSignal") and pkt.dBm_AntSignal is not None:
        return int(pkt.dBm_AntSignal)
    try:
        rt = pkt.getlayer(RadioTap)
        if rt and hasattr(rt, 'dBm_AntSignal'):
            return int(rt.dBm_AntSignal)
    except Exception:
        pass
    return None

def parse_vendor_ie(pkt):
    try:
        cur = pkt.getlayer(Dot11Elt)
        while cur is not None:
            if cur.ID == 221:
                return bytes(cur.info)
            cur = cur.payload.getlayer(Dot11Elt)
    except Exception:
        pass
    return None

# ---------------------------
# Main scan
# ---------------------------
def scan_for_cs60(iface, channels, dwell, monitor_script_path=None):
    print("[*] Scanning for CS60 beacons. Press Ctrl+C to stop.\n")
    try:
        while True:
            for ch in channels:
                print(f"[*] Switching to channel {ch}")
                set_channel(iface, ch, monitor_script_path)
                start = time.time()

                packets = sniff(iface=iface, timeout=dwell)
                for pkt in packets:
                    if not pkt.haslayer(Dot11Beacon):
                        continue

                    ssid = None
                    elt = pkt.getlayer(Dot11Elt)
                    while elt is not None:
                        if elt.ID == 0:
                            ssid = elt.info.decode(errors='ignore')
                            break
                        elt = elt.payload.getlayer(Dot11Elt)
                    if ssid != "CS60":
                        continue

                    bssid = pkt[Dot11].addr2
                    rssi = rssi_from_pkt(pkt)
                    vendor_payload = parse_vendor_ie(pkt)
                    vendor_str = ""
                    if vendor_payload:
                        vendor_str = vendor_payload.decode("utf-8", errors="replace")

                    ts = datetime.now().isoformat(timespec='seconds')
                    print(f"[SAMPLE] {ts} ch={ch:<2} bssid={bssid} rssi={rssi:<4} vendor_info='{vendor_str}'")

                elapsed = time.time() - start
                if elapsed < dwell:
                    time.sleep(max(0, dwell - elapsed))
    except KeyboardInterrupt:
        print("\n[!] Scan stopped by user.")
        print("[*] If you saw a vendor info string like 'go to channel 3', rerun:")
        print("    sudo python3 send_l2_frame.py --iface wlan0mon --id f0071xt --channel 3 --ap <AP_MAC>")

# ---------------------------
# CLI
# ---------------------------
def main():
    parser = argparse.ArgumentParser(description="Find CS60 beacon and print vendor info.")
    parser.add_argument("--iface", required=True)
    parser.add_argument("--dwell", type=float, default=0.5)
    parser.add_argument("--channels", nargs="*", type=int, default=list(range(1, 12)))
    args = parser.parse_args()

    script_dir = os.path.dirname(os.path.realpath(__file__))
    monitor_script = os.path.join(script_dir, "monitor-mode.sh")
    if not (os.path.isfile(monitor_script) and os.access(monitor_script, os.X_OK)):
        monitor_script = None

    scan_for_cs60(args.iface, args.channels, args.dwell, monitor_script)

if __name__ == "__main__":
    main()
