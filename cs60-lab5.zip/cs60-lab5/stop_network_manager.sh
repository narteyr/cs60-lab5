#!/bin/bash
# stop_network_manager.sh
# Bring wlan0 down, stop NetworkManager, then bring wlan0 up

echo "[*] Bringing wlan0 down..."
sudo ip link set wlan0 down

echo "[*] Stopping NetworkManager..."
sudo systemctl stop NetworkManager

echo "[*] Bringing wlan0 up..."
sudo ip link set wlan0 up

echo "[✓] NetworkManager stopped and wlan0 is ready."
