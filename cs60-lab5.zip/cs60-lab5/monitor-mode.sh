#!/bin/bash

# Usage: ./monitor-mode.sh <interface> <channel>
# Example: sudo ./monitor-mode.sh wlan0 6

if [[ -z $1 || -z $2 ]]; then
    echo "Usage: sudo ./monitor-mode.sh <interface> <channel>"
    exit 1
fi

interface_name=$1
channel=$2

echo "[*] Setting $interface_name to monitor mode on channel $channel..."

sudo ip link set "$interface_name" down
sudo iw dev "$interface_name" set type monitor
sudo ip link set "$interface_name" up
sudo iw dev "$interface_name" set channel "$channel"

echo
echo "[*] Verifying interface status:"
sudo iw dev | grep -A5 "$interface_name"
