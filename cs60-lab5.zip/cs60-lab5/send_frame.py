#!/usr/bin/env python3
"""
send_and_listen.py

Sends a Layer-2 frame to a target AP MAC on a specified
channel and sniffs for a reply containing the code/flag.

Usage:
  sudo ./send_and_listen.py --iface wlan0 --channel 3 --ap 98:48:27:c2:a7:9a --id f0071xt

Used ChatGPT for method formatting and control flow.
"""

import argparse
import subprocess
import sys
import time
import threading
from scapy.all import (
    sendp,
    sniff,
    RadioTap,
    Dot11,
    LLC,
    SNAP,
    Raw,
    get_if_hwaddr,
    RandMAC,
)

def check_root():
    if not hasattr(sys, "real_prefix") and sys.platform != "win32":
        # simple root check
        try:
            import os
            if os.geteuid() != 0:
                print("ERROR: this script must be run with sudo/root.")
                sys.exit(1)
        except AttributeError:
            pass

def set_channel(iface, channel):
    print(f"[*] Setting interface {iface} to channel {channel} (using iwconfig)...")
    try:
        subprocess.check_call(["iwconfig", iface, "channel", str(channel)])
    except subprocess.CalledProcessError as e:
        print(f"[!] Failed to set channel with iwconfig: {e}")
        print("[!] You may need to run this command manually, e.g.: sudo iwconfig wlan0mon channel 3")
        # proceed anyway

def build_frame(ap_mac, src_mac, payload_bytes):
    # Build a simple Data frame addressed to the AP (addr1=AP, addr2=our MAC, addr3=AP)
    frame = RadioTap() / Dot11(type=2, subtype=0, addr1=ap_mac, addr2=src_mac, addr3=ap_mac) / LLC() / SNAP() / Raw(load=payload_bytes)
    return frame

def sender_thread(iface, ap_mac, payload_bytes, src_mac, send_count, send_delay):
    frame = build_frame(ap_mac, src_mac, payload_bytes)
    print(f"[*] Sending {send_count} frames to {ap_mac} from {src_mac} on {iface} ...")
    for i in range(send_count):
        sendp(frame, iface=iface, verbose=False)
        # little pause; adjust if needed
        time.sleep(send_delay)
    print("[*] Done sending frames.")

def sniff_callback_factory(ap_mac):
    def handle(pkt):
        # Look for Raw payload from the AP (pkt.addr2 is source MAC for Dot11)
        try:
            if pkt.haslayer(Dot11) and pkt.haslayer(Raw):
                src = pkt.addr2
                if src is None:
                    return
                # accept packets whose source is the AP MAC
                if src.lower() == ap_mac.lower():
                    payload = pkt[Raw].load
                    # Try decode if bytes
                    try:
                        text = payload.decode("utf-8", errors="replace")
                    except Exception:
                        text = repr(payload)
                    print(f"\n[+] Received reply from {src}: {text}")
                    # stop sniffing by raising StopIteration via returning True to stop_filter
                    return payload  # not used directly; we use stop_filter below
        except Exception:
            pass
        return None
    return handle

def run_sniffer(iface, ap_mac, timeout, result_holder):
    # We'll use stop_filter to stop when we see a Raw from ap_mac
    def stop_filter(pkt):
        try:
            if pkt.haslayer(Dot11) and pkt.haslayer(Raw):
                if pkt.addr2 and pkt.addr2.lower() == ap_mac.lower():
                    payload = pkt[Raw].load
                    result_holder.append(payload)
                    return True
        except Exception:
            pass
        return False

    print(f"[*] Sniffing on {iface} for a reply from {ap_mac} (timeout {timeout}s)...")
    sniff(iface=iface, timeout=timeout, stop_filter=stop_filter, store=0)
    print("[*] Sniffer finished.")

def main():
    parser = argparse.ArgumentParser(description="Send Layer-2 frame to AP and listen for reply.")
    parser.add_argument("--iface", required=True, help="monitor-mode interface (e.g. wlan0mon)")
    parser.add_argument("--channel", required=True, type=int, help="channel to set (e.g. 3)")
    parser.add_argument("--ap", required=True, help="target AP MAC (BSSID), e.g. 98:48:27:c2:a7:9a")
    parser.add_argument("--id", required=True, help="Dartmouth ID payload to send, e.g. f0071xt")
    parser.add_argument("--send-count", type=int, default=6, help="how many frames to send")
    parser.add_argument("--send-delay", type=float, default=0.5, help="delay between sends (s)")
    parser.add_argument("--sniff-timeout", type=int, default=12, help="how long to sniff for reply (s)")
    args = parser.parse_args()

    check_root()
    iface = args.iface
    channel = args.channel
    ap_mac = args.ap
    dart_id = args.id
    send_count = args.send_count
    send_delay = args.send_delay
    sniff_timeout = args.sniff_timeout

    # Set channel (attempt)
    set_channel(iface, channel)
    time.sleep(0.5)

    # Determine source MAC (may not always be available in monitor mode)
    try:
        src_mac = get_if_hwaddr(iface)
        if src_mac == "00:00:00:00:00:00":
            raise Exception("invalid mac")
    except Exception:
        src_mac = str(RandMAC())
        print(f"[!] Could not get hardware MAC for {iface}. Using random MAC {src_mac}")

    payload_bytes = dart_id.encode("utf-8")

    # Start sniffer thread
    result_holder = []
    sniffer = threading.Thread(target=run_sniffer, args=(iface, ap_mac, sniff_timeout, result_holder), daemon=True)
    sniffer.start()

    # Short sleep to ensure sniffer is listening
    time.sleep(0.5)

    # Send frames
    sender_thread(iface, ap_mac, payload_bytes, src_mac, send_count, send_delay)

    # Wait for sniffer to finish or until we have result
    sniffer.join(timeout=sniff_timeout + 1)

    if result_holder:
        payload = result_holder[0]
        try:
            text = payload.decode("utf-8", errors="replace")
        except Exception:
            text = repr(payload)
        print(f"\n=== FLAG/Code RECEIVED ===\n{str(text)}\n==========================")
    else:
        print("\n[!] No reply captured. Try increasing send-count, sniff-timeout, or resend frames.\n")

if __name__ == "__main__":
    main()
